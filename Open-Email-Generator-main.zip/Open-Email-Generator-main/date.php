<?php


//date
echo date('d F Y');
 

?>